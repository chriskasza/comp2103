
  // Tomasz Muldner, September 2001
  // A program for the book:
  //  "C++ Programming with Design Patterns Revealed", published by Addison-Wesley, 2002
  // File: ch5.studentwithaccount.cpp
  #include "ch5.studentwithaccount.h"
  #include "ch5.student.h"
  StudentWithAccount::StudentWithAccount(long number, 
            string name, double balance) : 

              Student(number, name) // base class' constructor
  {
    balance_ = balance;
  }
  double StudentWithAccount::getBalance() const {
    return balance_;
 }

 void StudentWithAccount::setBalance(double balance) {
    balance_ = balance;
 }

 void StudentWithAccount::printInfo() const {
   Student::printInfo();
   cout << "balance: " << balance_ << endl;
 }
  void StudentWithAccount::info(const Student& s, 
      const StudentWithAccount& swa) {
  //  cout << s.number_; // can't access through Student
    cout << swa.number_; // can access through StudentWithAccount
  }


