
  // Tomasz Muldner, September 2001
  // A program for the book:
  //  "C++ Programming with Design Patterns Revealed", published by Addison-Wesley, 2002
  // Example 5.4
  // Simple test program
#include "ex5.4.Mybenchmarkclass.h"
#include "ex5.4.benchmarkclass.h"
#include <iostream>
using namespace std;
int main() {
  BenchmarkClass* b = new MyBenchmarkClass();
  cout << b->repeat(1000000) << endl;

}
