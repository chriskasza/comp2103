
  // Tomasz Muldner, September 2001
  // A program for the book:
  //  "C++ Programming with Design Patterns Revealed", published by Addison-Wesley, 2002
  // Simple tester program for Example 5.5
#include <iostream>
using namespace std;
#include "ex5.5.downtownstore.h"
#include "ex5.5.neighborhoodstore.h"
int main() {
  const int UNITS = 25;
  const double PERUNIT = 10;
  Store* s1 = new DowntownStore(PERUNIT); // default tax rate, 25 units
  Store* s2 = new NeighborhoodStore(PERUNIT+40); 
  cout << "for " << UNITS << " units, pay " << endl;
  cout << "downtown: " << s1->getBillableAmount(UNITS) << endl;
  cout << "neighborhood: " << s2->getBillableAmount(UNITS) << endl; 
}

