  // Tomasz Muldner, September 2001
  // A program for the book:
  //  "C++ Programming with Design Patterns Revealed", published by Addison-Wesley, 2002
  // File: ex5.2.driver.cpp
  // Example 5.2
  // Main program to test exception handling
  #include <limits>
  #include "ex5.2.Myoverflow.h"
  #include "ex5.2.Myunderflow.h"

  int add(int x, int y) throw(My_overflow_error, My_underflow_error) {
    if(x > 0 && y > 0 && x > numeric_limits<int>::max() - y)
      throw My_overflow_error("can't add ", x, y);
    if(x < 0 && y < 0 && x < numeric_limits<int>::min() - y)
      throw My_underflow_error("can't add", x, y);
    return x + y;
  }

int main() {
  try {
    int x, y;
    cout << "enter two integers ";
    cin >> x;
    cin >> y;
    
    int result = add(x, y);
    cout << endl << result << endl;
  }
  catch(const My_overflow_error& exc) {
    cerr < exc.what() << exc.getArg1() << " " << exc.getArg2() << endl;
  }
  catch(const My_underflow_error& exc) {
    cerr < exc.what() << exc.getArg1() << " " << exc.getArg2() << endl;
  }

}

