
  // Tomasz Muldner, September 2001
  // A program for the book:
  //  "C++ Programming with Design Patterns Revealed", published by Addison-Wesley, 2002
  // File: ch5.student.cpp
  // Example 5.1
  // Interface for class Student
  #include "ch5.student.h"
  #include <iostream>
  using namespace std;
  void Student::printInfo() const {
    cout << "Student number:" << number_ << "; name:" 
        << name_ << endl;
  }
  long Student::getNumber() const {
    return number_;
  }

  string Student::getName() const {
    return name_;
  }

  Student::Student(long number, string name) : number_(number), name_(name) {}


