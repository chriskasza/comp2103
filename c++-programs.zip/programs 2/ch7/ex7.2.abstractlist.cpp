  // Tomasz Muldner, September 2001
  // A program for the book:
  //  "C++ Programming with Design Patterns Revealed", published by Addison-Wesley, 2002
  //  File: ex7.2.abstractlist.cpp
  // Implemetation of class  AbstractList
#include "ex7.2.abstractlist.h"
 namespace LIST_POLYMORPHIC_ITERATION {

    AbstractList::AbstractList() {}
    AbstractList::~AbstractList() {}
}

