
  // Tomasz Muldner, September 2001
  // A program for the book:
  //  "C++ Programming with Design Patterns Revealed", published by Addison-Wesley, 2002
  // File: ch2-change.cpp
   int* changeable(int arr[], int size, int p) {
    // return a pointer to the p-th element
    if(p < 0 || p >= size) 
      return 0;   // error

    return &arr[p];
  }
 
  const int* nonChangeable(const int arr[], int size, int p) {
    // return a pointer to the p-th element
    if(p < 0 || p >= size) 
      return 0;   // error

    return &arr[p];
  }

  const int* const constAccess(const int arr[], int size, int p) {
    // return a pointer to the p-th element
    if(p < 0 || p >= size) 
      return 0;   // error

    return &arr[p];
  }

#include <iostream>
using namespace std;

int main() {
  int x[] = {1, 2, 3};
  int* i = changeable(x, 3, 2);
  *i = 3;  // OK, can modify through i

  const int *j = nonChangeable(x, 3, 2);
  cout << *j;
  //   *j = 3; // can't assign to a const
  // i = nonChangeable(x, 3, 2);  // can't assign to a non-const

  const int* const p = constAccess(x, 3, 1);

}
