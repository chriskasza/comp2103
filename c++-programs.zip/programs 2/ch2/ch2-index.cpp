  // Tomasz Muldner, September 2001
  // A program for the book:
  //  "C++ Programming with Design Patterns Revealed", published by Addison-Wesley, 2002
  // File: ch2-index.cpp
  int& index(int x[], int i) {
    // gives read/write access to the i-th element of x
    return x[i];
  }
 
  const int& get(const int x[], int pos) {
    return x[pos];
  }
 
#include <iostream>
using namespace std;

int main() {

  int a[5]; 
  cout << "enter 5 values " << endl;
  for(int i = 0; i < 5; i++)
    cin >> index(a, i);
  cout << "array is: ";  
  for(int i = 0; i < 5; i++)
    cout << index(a, i) << "\t";

  cout << endl << "array is: ";
  for(int i = 0; i < 5; i++)  
     cout << a[i] << "\t";
  cout << endl;


  cout << "using get, the 2nd element is " << get(a,2) << endl;
  // cin >> get(a,1);   error - can't change the value
}

