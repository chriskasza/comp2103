
  // Tomasz Muldner, September 2001
  // A program for the book:
  //  "C++ Programming with Design Patterns Revealed", published by Addison-Wesley, 2002
  //File: ex6.3.attributedobject.cpp
  // Implementation for the class AttributedObject
  #include "ex6.3.attributedobject.h"
  AttributedObject::~AttributedObject() {
    // do nothing, just define virtual destructor
  }
