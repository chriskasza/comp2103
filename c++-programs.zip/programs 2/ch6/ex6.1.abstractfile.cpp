
  // Tomasz Muldner, September 2001
  // A program for the book:
  //  "C++ Programming with Design Patterns Revealed", published by Addison-Wesley, 2002
  // File ex6.1.abstractfile.cpp
  // Implementation for the class AbstractFileOps

  #include "ex6.1.abstractfile.h"

    // AbstractFileOps::AbstractFileOps() {}
   AbstractFileOps::~AbstractFileOps() {}

