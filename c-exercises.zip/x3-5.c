/*
Exercise 3-5

The output of the following statement:

printf("What did you ask ??(do not whisper)??");

would be:


What did you ask [do not whisper)??

*/

