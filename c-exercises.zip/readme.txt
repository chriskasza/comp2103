
This is a list of all examples from the book  book "C for Java Programmers"
Convention:

For exercise n from chapter C, the filename is:

xn-C.c

for example; for exercise 5 from Chapter 3:
x3-5.c

For each chapter, there is a makefile,
that can be used as follows:

# run: make -f 3.make target
# For example:
# make -f 3.make x3-5

and then, to run this program, use

x3-5


Chapter 3:

1,5,9,13,17		
-----------------------------------------
Chapter 4:

1,5,9,13,17,21		
----------------------------------------
Chapter 5:

1,5,9,13,17		
----------------------------------------
Chapter 6:

1,5		
----------------------------------------
Chapter 7:

1,5,9,13,17,21,25,29	
----------------------------------------
Chapter 8:

1,5,9			
----------------------------------------
Chapter 9:

1,5,9,13,21		
----------------------------------------
Chapter 10:

5,9,13		
----------------------------------------
Chapter 11:

1
----------------------------------------
Chapter 12:

11			
----------------------------------------
Chapter 13:

1,5,9,13,17,21		
----------------------------------------
Chapter 14:

1,5,9,13		
----------------------------------------

