/*
Exercise 3-1

a) x+++y is broken down into four tokens:
x, ++, +, y
or, in an easier way to read (x++) + y

b) x++>=++y is broken down into five tokens:
x, ++, >=, ++, y
or, simply (x++) >= (y++)
*/

